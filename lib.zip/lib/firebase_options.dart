import 'package:firebase_core/firebase_core.dart';

const FirebaseOptions firebaseOptions = FirebaseOptions(
    apiKey: "AIzaSyDeVo-jqJ6SOZ6cdU7b3LMKs4xXcS0Qii4",
    authDomain: "duolingo-d39e2.firebaseapp.com",
    projectId: "duolingo-d39e2",
    storageBucket: "duolingo-d39e2.firebasestorage.app",
    messagingSenderId: "672489039422",
    appId: "1:672489039422:web:98f3048694507d2650936f",
    measurementId: "G-G9BG78697J"
);

